dotnet publish DiscFit.csproj -c Release -r win-x64 -p:PublishSingleFile=true > build_log.txt 2>&1
